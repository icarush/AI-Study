import argparse, json, math, os, time
from typing import Dict, Any, Iterable, Tuple

# 우선 torch의 SummaryWriter를 우선 사용, 없으면 tensorboardX 사용
try
    from torch.utils.tensorboard import SummaryWriter
    BACKEND = torch
except Exception
    try
        from tensorboardX import SummaryWriter
        BACKEND = tensorboardX
    except Exception as e
        raise SystemExit(Install torch (torch.utils.tensorboard) or tensorboardX first.) from e

# SG1SG2에서 자주 쓰는 후보 키들
CAND_STEP_KEYS = [
    kimg, cur_kimg, cur_nimg, nimg, images, img,
    step, iter, iteration, tick, epoch, global_step
]

IGNORE_KEYS = {
    # 시간메타
    time, timestamp, walltime, host, event,
    # 경로나 스냅샷 문자열 등
    snapshot_pkl, network_snapshot, pkl, image_path, model_path
}

def as_number(x)
    try
        v = float(x)
        return v if math.isfinite(v) else None
    except Exception
        return None

def flatten(d Dict[str, Any], prefix str = ) - Iterable[Tuple[str, Any]]
    중첩 dict를 'abc' 형태의 태그로 평탄화.
    for k, v in d.items()
        tag = f{prefix}{k} if prefix else str(k)
        if isinstance(v, dict)
            yield from flatten(v, tag)
        else
            yield tag, v

def pick_step(rec Dict[str, Any], explicit_key str = None, last_step float = 0.0) - float
    # 명시 키가 있으면 최우선
    if explicit_key and explicit_key in rec
        val = as_number(rec[explicit_key])
        if val is not None
            return val  1000.0 if explicit_key == cur_nimg else val

    # SG1에서 cur_nimg를 많이 쓰므로 cur_nimg → kimg 변환 우선 처리
    if cur_nimg in rec
        val = as_number(rec[cur_nimg])
        if val is not None
            return val  1000.0

    # 나머지 후보 키들
    for k in CAND_STEP_KEYS
        if k in rec
            val = as_number(rec[k])
            if val is not None
                return val
    # 아무 것도 없으면 라인 순번 사용
    return last_step + 1.0

def pick_walltime(rec Dict[str, Any]) - float
    for k in (time, timestamp, walltime)
        if k in rec
            v = as_number(rec[k])
            if v is not None
                return v
    return time.time()

def main(in_path str, out_dir str, step_key str = None, include list = None, exclude list = None)
    os.makedirs(out_dir, exist_ok=True)
    writer = SummaryWriter(log_dir=out_dir)

    step = 0.0
    with open(in_path, r, encoding=utf-8, errors=ignore) as f
        for line in f
            line = line.strip()
            if not line
                continue
            try
                rec = json.loads(line)
            except json.JSONDecodeError
                # 로그 사이에 다른 출력이 끼어든 경우 무시
                continue

            wall = pick_walltime(rec)
            step = pick_step(rec, explicit_key=step_key, last_step=step)

            # 평탄화 후 숫자형만 스칼라로 기록
            for tag, val in flatten(rec)
                base_key = tag.split()[-1]
                if base_key in IGNORE_KEYS or tag == step_key
                    continue
                num = as_number(val)
                if num is None
                    continue

                # 선택적 필터
                if include and not any(tag.startswith(p) for p in include)
                    continue
                if exclude and any(tag.startswith(p) for p in exclude)
                    continue

                # 공백은 밑줄로 교체
                safe_tag = tag.replace( , _)
                writer.add_scalar(safe_tag, num, global_step=step, walltime=wall)

    writer.flush()
    writer.close()
    print(f[OK] Wrote TensorBoard events to {out_dir} (backend={BACKEND}))

if __name__ == __main__
    ap = argparse.ArgumentParser()
    ap.add_argument(--in,  dest=in_path, required=True, help=Path to StyleGAN1 stats.jsonl)
    ap.add_argument(--out, dest=out_dir, required=True, help=Output directory for TensorBoard events)
    ap.add_argument(--step_key, default=None, help=Force a specific step key (e.g., kimg). If omitted, auto-detect; cur_nimg→kimg handled.)
    ap.add_argument(--include, nargs=, default=None, help=Include only tags with these prefixes (optional))
    ap.add_argument(--exclude, nargs=, default=None, help=Exclude tags with these prefixes (optional))
    args = ap.parse_args()
    main(args.in_path, args.out_dir, step_key=args.step_key, include=args.include, exclude=args.exclude)
