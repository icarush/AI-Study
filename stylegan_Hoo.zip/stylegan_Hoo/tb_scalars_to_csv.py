
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
tb_scalars_to_csv.py
--------------------
Export selected (or all) scalar tags from a TensorBoard event file or logdir to CSV.

Usage:
  python tb_scalars_to_csv.py --logdir "D:/runs/exp/tb_from_jsonl" --out "D:/runs/exp/scalars.csv"
  python tb_scalars_to_csv.py --event "D:/runs/exp/tb_from_jsonl/events.out.tfevents.*" --out "D:/runs/exp/scalars.csv" --tags "metrics/retouch/*,metrics/relight/*,metrics/fid50k/*"

Requires:
  pip install tensorboard
"""
import argparse, glob, re
from pathlib import Path
import csv

def pick_event_file(logdir_or_glob):
    paths = []
    p = Path(logdir_or_glob)
    if p.is_dir():
        for child in p.iterdir():
            if child.is_file() and child.name.startswith("events.out.tfevents"):
                paths.append(str(child))
    else:
        paths = glob.glob(logdir_or_glob)
    if not paths:
        raise SystemExit(f"No event files found under: {logdir_or_glob}")
    # newest
    paths.sort(key=lambda s: Path(s).stat().st_mtime, reverse=True)
    return paths[0]

def main():
    ap = argparse.ArgumentParser()
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--logdir")
    g.add_argument("--event")
    ap.add_argument("--out", required=True, help="Output CSV path")
    ap.add_argument("--tags", default="", help="Comma-separated glob patterns for tags; empty means all scalars")
    args = ap.parse_args()

    try:
        from tensorboard.backend.event_processing import event_accumulator as EA
    except Exception as e:
        raise SystemExit("Please install `tensorboard` (pip install tensorboard)") from e

    ev_path = pick_event_file(args.logdir or args.event)
    ea = EA.EventAccumulator(ev_path, size_guidance={"scalars": 0})
    ea.Reload()

    scalar_tags = ea.Tags().get("scalars", [])
    patterns = [t.strip() for t in args.tags.split(",") if t.strip()]
    def tag_selected(tag):
        if not patterns:
            return True
        for pat in patterns:
            # convert simple glob to regex
            r = re.escape(pat).replace("\\*", ".*")
            if re.fullmatch(r, tag):
                return True
        return False

    rows = []
    for tag in scalar_tags:
        if not tag_selected(tag):
            continue
        for ev in ea.Scalars(tag):
            rows.append({"tag": tag, "step": ev.step, "value": float(ev.value), "wall_time": ev.wall_time})

    rows.sort(key=lambda r: (r["tag"], r["step"]))

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with out_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["tag","step","value","wall_time"])
        w.writeheader()
        for r in rows:
            w.writerow(r)

    print("[OK] wrote:", out_path)

if __name__ == "__main__":
    main()
