
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
eval_metrics_to_jsonl_ext.py
----------------------------
Compute retouch/relight metrics from BEFORE/AFTER image pairs and write them to
JSONL in three possible modes:
  - avg        : one line per metric (dataset average)          [default]
  - per_image  : one line per image pair (step = pair index)
  - chunks N   : N chunks; write one line per chunk (average over that chunk)

This helps produce *multiple* points in TensorBoard (per_image or chunked),
so you can draw curves instead of a single dot.

Usage examples (Windows, CMD):
  :: 평균 1줄 (기존과 동일)
  python eval_metrics_to_jsonl_ext.py ^
    --before_dir "F:/data/before" ^
    --after_dir  "F:/data/after"  ^
    --retouch_jsonl "F:/runs/metric-retouch.jsonl" ^
    --relight_jsonl "F:/runs/metric-relight.jsonl" ^
    --mode avg --kimg 240.0

  :: 이미지별 로그(여러 점)
  python eval_metrics_to_jsonl_ext.py ^
    --before_dir "F:/data/before" ^
    --after_dir  "F:/data/after"  ^
    --retouch_jsonl "F:/runs/metric-retouch-perimg.jsonl" ^
    --relight_jsonl "F:/runs/metric-relight-perimg.jsonl" ^
    --mode per_image

  :: 10개 청크로 나눠 각 청크 평균(10개의 점)
  python eval_metrics_to_jsonl_ext.py ^
    --before_dir "F:/data/before" ^
    --after_dir  "F:/data/after"  ^
    --retouch_jsonl "F:/runs/metric-retouch-chunks.jsonl" ^
    --relight_jsonl "F:/runs/metric-relight-chunks.jsonl" ^
    --mode chunks --num_chunks 10 --cur_nimg_start 240000 --cur_nimg_stride 1

Optional deps (추천):
    pip install numpy opencv-python scikit-image torch lpips insightface onnxruntime
"""
import argparse, json, time, math, os
from pathlib import Path
import numpy as np, cv2
from skimage.metrics import structural_similarity as ssim
from skimage.color import rgb2lab

# Optional: LPIPS
_HAS_LPIPS = True
try:
    import torch, lpips
except Exception:
    _HAS_LPIPS = False
    torch = None
    lpips = None

# Optional: InsightFace (ArcFace embeddings)
_HAS_INSIGHT = True
try:
    from insightface.app import FaceAnalysis
except Exception:
    _HAS_INSIGHT = False
    FaceAnalysis = None

IMG_EXTS = {".jpg",".jpeg",".png",".bmp",".webp",".tif",".tiff"}

def list_pairs(before_dir: Path, after_dir: Path, max_pairs=None):
    befores = [p for p in sorted(before_dir.iterdir()) if p.suffix.lower() in IMG_EXTS]
    pairs = []
    for b in befores:
        a = after_dir / b.name
        if a.exists():
            pairs.append((b, a))
            if max_pairs and len(pairs) >= max_pairs:
                break
    return pairs

def read_rgb(path: Path, max_size=None):
    im = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if im is None:
        raise RuntimeError(f"read failed: {path}")
    if im.ndim == 2:
        im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
    if im.shape[2] == 4:
        im = im[:, :, :3]
    if max_size and max(im.shape[:2]) > max_size:
        h,w = im.shape[:2]; s = float(max_size)/float(max(h,w))
        im = cv2.resize(im, (int(w*s), int(h*s)), interpolation=cv2.INTER_AREA)
    im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB).astype(np.float32)/255.0
    return im

def center_crop(img, frac=0.6):
    H,W = img.shape[:2]
    s = int(min(H,W)*frac)
    y1 = (H-s)//2; x1 = (W-s)//2
    return img[y1:y1+s, x1:x1+s].copy()

def get_face_bbox(app, img_rgb):
    if app is None: return None
    H,W = img_rgb.shape[:2]
    faces = app.get((img_rgb*255).astype(np.uint8))
    if not faces: return None
    f = max(faces, key=lambda f:(f.bbox[2]-f.bbox[0])*(f.bbox[3]-f.bbox[1]))
    x1,y1,x2,y2 = map(int, f.bbox)
    x1=max(0,x1); y1=max(0,y1); x2=min(W-1,x2); y2=min(H-1,y2)
    pad=int(0.1*max(x2-x1,y2-y1))
    x1=max(0,x1-pad); y1=max(0,y1-pad); x2=min(W-1,x2+pad); y2=min(H-1,y2+pad)
    return [x1,y1,x2,y2]

def crop_by_bbox(img,b):
    x1,y1,x2,y2=b; return img[y1:y2, x1:x2].copy()

def resize_pair(a,b,size=256):
    a2=cv2.resize(a,(size,size),interpolation=cv2.INTER_AREA)
    b2=cv2.resize(b,(size,size),interpolation=cv2.INTER_AREA)
    return a2,b2

def y_luma(rgb):
    r,g,b=rgb[...,0],rgb[...,1],rgb[...,2]
    return 0.2126*r + 0.7152*g + 0.0722*b

def laplacian_energy(gray):
    lap = cv2.Laplacian(gray, cv2.CV_32F, ksize=3)
    return float(np.mean(np.abs(lap)))

def sobel_mag(gray):
    gx=cv2.Sobel(gray,cv2.CV_32F,1,0,ksize=3)
    gy=cv2.Sobel(gray,cv2.CV_32F,0,1,ksize=3)
    return np.sqrt(gx*gx+gy*gy)

def deltaE_to_neutral(rgb_face):
    lab = rgb2lab(np.clip(rgb_face,0,1))
    a = float(np.mean(lab[...,1])); b = float(np.mean(lab[...,2]))
    return float(np.sqrt(a*a + b*b))

def append_jsonl(jsonl_path, metric_name, results, kimg=None, cur_nimg=None):
    rec = {"metric":metric_name,"results":results,"timestamp":time.time()}
    if kimg is not None: rec["kimg"]=float(kimg)
    if cur_nimg is not None: rec["cur_nimg"]=int(cur_nimg)
    p = Path(jsonl_path); p.parent.mkdir(parents=True,exist_ok=True)
    with open(p,"a",encoding="utf-8") as f:
        f.write(json.dumps(rec)+"\n")

def eval_pairs(before_dir, after_dir, max_pairs=None, max_size=1024, device="cpu"):
    # Prepare optional models
    device_ok = device if (_HAS_LPIPS and device=="cuda" and torch and torch.cuda.is_available()) else "cpu"
    lpips_model=None
    if _HAS_LPIPS:
        try:
            lpips_model = lpips.LPIPS(net='vgg').to(device_ok); lpips_model.eval()
        except Exception:
            lpips_model=None
    face_app=None
    if _HAS_INSIGHT:
        try:
            face_app = FaceAnalysis(name='buffalo_l')
            face_app.prepare(ctx_id=0 if device_ok=="cuda" else -1, det_size=(640,640))
        except Exception:
            face_app=None

    pairs = list_pairs(Path(before_dir), Path(after_dir), max_pairs=max_pairs)
    if not pairs:
        raise SystemExit("no matching filename pairs found")

    per_image = []  # list of dicts with metrics for each pair
    for (bp, ap_) in pairs:
        try:
            b = read_rgb(bp, max_size); a = read_rgb(ap_, max_size)
        except Exception:
            continue
        bb = get_face_bbox(face_app, b) if face_app else None
        ba = get_face_bbox(face_app, a) if face_app else None
        fb = crop_by_bbox(b, bb) if bb else center_crop(b)
        fa = crop_by_bbox(a, ba) if ba else center_crop(a)
        fb, fa = resize_pair(fb, fa, 256)

        m = {}

        # id_sim (ArcFace embeddings cosine)
        if face_app:
            try:
                fb_list = face_app.get((fb*255).astype(np.uint8))
                fa_list = face_app.get((fa*255).astype(np.uint8))
                if fb_list and fa_list:
                    e1 = fb_list[0].normed_embedding; e2 = fa_list[0].normed_embedding
                    m["id_sim"] = float(np.dot(e1, e2))
            except Exception:
                pass

        # LPIPS (optional)
        if lpips_model:
            try:
                at = torch.from_numpy(fb).permute(2,0,1).unsqueeze(0).float()*2-1
                bt = torch.from_numpy(fa).permute(2,0,1).unsqueeze(0).float()*2-1
                at=at.to(device_ok); bt=bt.to(device_ok)
                with torch.no_grad():
                    d = lpips_model(at, bt).squeeze().detach().cpu().numpy().item()
                m["lpips_face"]=float(d)
            except Exception:
                pass

        # SSIM
        try:
            s = float(ssim(fb, fa, data_range=1.0, channel_axis=2))
            m["ssim_face"]=s
        except Exception:
            pass

        # Skin HF energy on after
        try:
            gA = cv2.cvtColor((fa*255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32)/255.0
            m["skin_hf_energy"]=laplacian_energy(gA)
        except Exception:
            pass

        # Artifact ratio (new strong edges in after vs before)
        try:
            gB = cv2.cvtColor((fb*255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32)/255.0
            gA = cv2.cvtColor((fa*255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32)/255.0
            mb = sobel_mag(gB); ma = sobel_mag(gA)
            thr = float(np.percentile(mb, 95.0))
            strong_b = (mb > thr).astype(np.float32)
            strong_a = (ma > thr).astype(np.float32)
            art = float(np.maximum(strong_a-strong_b,0).mean())
            m["artifact_ratio"]=art
        except Exception:
            pass

        # Relight metrics on after
        try:
            Y = y_luma(fa)
            m["face_luma_L1"]=float(np.mean(np.abs(Y - 0.5)))
            m["clipped_ratio"]=float(np.mean((Y<=0.01)|(Y>=0.99)))
            m["wb_deltaE"]=float(deltaE_to_neutral(fa))
        except Exception:
            pass

        per_image.append(m)

    return per_image

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--before_dir", required=True)
    ap.add_argument("--after_dir",  required=True)
    ap.add_argument("--retouch_jsonl", default=None)
    ap.add_argument("--relight_jsonl", default=None)
    ap.add_argument("--mode", choices=["avg","per_image","chunks"], default="avg")
    ap.add_argument("--num_chunks", type=int, default=10, help="when --mode chunks")
    ap.add_argument("--kimg", type=float, default=None, help="record as kimg (one value or start value)")
    ap.add_argument("--cur_nimg_start", type=int, default=None, help="start step when writing multiple lines")
    ap.add_argument("--cur_nimg_stride", type=int, default=1, help="step increment when writing multiple lines")
    ap.add_argument("--max_pairs", type=int, default=None)
    ap.add_argument("--max_size", type=int, default=1024)
    ap.add_argument("--device", choices=["cpu","cuda"], default="cpu")
    args = ap.parse_args()

    per_image = eval_pairs(args.before_dir, args.after_dir, args.max_pairs, args.max_size, args.device)
    n = len(per_image)
    if n == 0:
        raise SystemExit("no valid pairs")

    def avg_dict(items):
        keys = set().union(*[d.keys() for d in items if isinstance(d, dict)])
        out = {}
        for k in keys:
            vals = [d[k] for d in items if k in d and isinstance(d[k], (int,float)) and math.isfinite(d[k])]
            if vals:
                out[k] = float(np.mean(vals))
        out["n_pairs"] = len(items)
        return out

    # mode: avg (one line)
    if args.mode == "avg":
        if args.retouch_jsonl:
            r = avg_dict(per_image)
            ret = {k:v for k,v in r.items() if k in ("id_sim","lpips_face","skin_hf_energy","artifact_ratio","n_pairs") and k in r}
            append_jsonl(args.retouch_jsonl, "retouch", ret, kimg=args.kimg)
            print("[OK] wrote avg retouch to", args.retouch_jsonl, ret)
        if args.relight_jsonl:
            r = avg_dict(per_image)
            rel = {k:v for k,v in r.items() if k in ("face_luma_L1","clipped_ratio","wb_deltaE","lpips_face","ssim_face","n_pairs") and k in r}
            append_jsonl(args.relight_jsonl, "relight", rel, kimg=args.kimg)
            print("[OK] wrote avg relight to", args.relight_jsonl, rel)
        return

    # build sequence of groups (per-image or chunks)
    groups = []
    if args.mode == "per_image":
        for i, m in enumerate(per_image):
            groups.append(([m], i))  # (list_of_items, index)
    elif args.mode == "chunks":
        c = max(1, int(args.num_chunks))
        size = max(1, n // c)
        start = 0
        for i in range(c):
            end = n if (i==c-1) else min(n, start+size)
            if start>=end: break
            groups.append((per_image[start:end], i))
            start = end

    # step assignment
    base = args.cur_nimg_start
    stride = max(1, int(args.cur_nimg_stride))
    step = base if base is not None else None

    # write lines
    for items, idx in groups:
        step_val = step if step is not None else idx
        r = avg_dict(items)
        if args.retouch_jsonl:
            ret = {k:v for k,v in r.items() if k in ("id_sim","lpips_face","skin_hf_energy","artifact_ratio","n_pairs") and k in r}
            append_jsonl(args.retouch_jsonl, "retouch", ret, kimg=None, cur_nimg=step_val)
        if args.relight_jsonl:
            rel = {k:v for k,v in r.items() if k in ("face_luma_L1","clipped_ratio","wb_deltaE","lpips_face","ssim_face","n_pairs") and k in r}
            append_jsonl(args.relight_jsonl, "relight", rel, kimg=None, cur_nimg=step_val)
        if step is not None:
            step += stride

    print(f"[OK] wrote {len(groups)} lines to JSONL (mode={args.mode})")

if __name__ == "__main__":
    main()
