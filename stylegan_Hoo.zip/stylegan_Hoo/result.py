#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Evaluate retouch (blemish removal) & relight (backlight correction) metrics
from pairs of images (before vs. after), then append JSONL lines so they can
be converted and viewed in TensorBoard later.

Usage (example):
    python eval_retouch_relight_to_jsonl.py \
        --before_dir "F:\AI/Gan Before" \
        --after_dir  "F:\AI/Gan Result"  \
        --retouch_jsonl "F:/runs/metric-retouch.jsonl" \
        --relight_jsonl "F:/runs/metric-relight.jsonl" \
        --kimg 240.0

Optional deps:
    pip install numpy opencv-python scikit-image torch lpips insightface onnxruntime
"""
import argparse, os, json, time, math
from pathlib import Path
import numpy as np, cv2
from skimage.metrics import structural_similarity as ssim
from skimage.color import rgb2lab

# Optional: LPIPS
try:
    import torch, lpips
    _HAS_LPIPS = True
except Exception:
    _HAS_LPIPS = False
    torch = None
    lpips = None

# Optional: InsightFace (face detection + embeddings for id_sim)
try:
    from insightface.app import FaceAnalysis
    _HAS_INSIGHT = True
except Exception:
    _HAS_INSIGHT = False
    FaceAnalysis = None

IMG_EXTS = {".jpg",".jpeg",".png",".bmp",".webp",".tif",".tiff"}

def list_pairs(before_dir: Path, after_dir: Path, max_pairs=None):
    befores = [p for p in sorted(before_dir.iterdir()) if p.suffix.lower() in IMG_EXTS]
    pairs = []
    for b in befores:
        a = after_dir / b.name
        if a.exists():
            pairs.append((b, a))
            if max_pairs and len(pairs) >= max_pairs:
                break
    return pairs

def read_rgb(path: Path, max_size=None):
    im = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if im is None:
        raise RuntimeError(f"read failed: {path}")
    if im.ndim == 2:
        im = cv2.cvtColor(im, cv2.COLOR_GRAY2BGR)
    if im.shape[2] == 4:
        im = im[:, :, :3]
    if max_size and max(im.shape[:2]) > max_size:
        h,w = im.shape[:2]; s = float(max_size)/float(max(h,w))
        im = cv2.resize(im, (int(w*s), int(h*s)), interpolation=cv2.INTER_AREA)
    im = cv2.cvtColor(im, cv2.COLOR_BGR2RGB).astype(np.float32)/255.0
    return im

def center_crop(img, frac=0.6):
    H,W = img.shape[:2]
    s = int(min(H,W)*frac)
    y1 = (H-s)//2; x1 = (W-s)//2
    return img[y1:y1+s, x1:x1+s].copy()

def get_face_bbox(app, img_rgb):
    if app is None: return None
    H,W = img_rgb.shape[:2]
    faces = app.get((img_rgb*255).astype(np.uint8))
    if not faces: return None
    # largest face
    f = max(faces, key=lambda f:(f.bbox[2]-f.bbox[0])*(f.bbox[3]-f.bbox[1]))
    x1,y1,x2,y2 = map(int, f.bbox)
    x1=max(0,x1); y1=max(0,y1); x2=min(W-1,x2); y2=min(H-1,y2)
    pad = int(0.1*max(x2-x1,y2-y1))
    x1=max(0,x1-pad); y1=max(0,y1-pad); x2=min(W-1,x2+pad); y2=min(H-1,y2+pad)
    return [x1,y1,x2,y2]

def crop_by_bbox(img,b):
    x1,y1,x2,y2=b; return img[y1:y2, x1:x2].copy()

def resize_pair(a,b,size=256):
    a2=cv2.resize(a,(size,size),interpolation=cv2.INTER_AREA)
    b2=cv2.resize(b,(size,size),interpolation=cv2.INTER_AREA)
    return a2,b2

def to_torch(t):
    ten = torch.from_numpy(t).permute(2,0,1).unsqueeze(0).float()
    return ten*2.0-1.0

def y_luma(rgb):
    r,g,b = rgb[...,0],rgb[...,1],rgb[...,2]
    return 0.2126*r + 0.7152*g + 0.0722*b

def laplacian_energy(gray):
    lap = cv2.Laplacian(gray, cv2.CV_32F, ksize=3)
    return float(np.mean(np.abs(lap)))

def sobel_mag(gray):
    gx=cv2.Sobel(gray,cv2.CV_32F,1,0,ksize=3)
    gy=cv2.Sobel(gray,cv2.CV_32F,0,1,ksize=3)
    return np.sqrt(gx*gx+gy*gy)

def deltaE_to_neutral(rgb_face):
    lab = rgb2lab(np.clip(rgb_face,0,1))
    a = float(np.mean(lab[...,1])); b = float(np.mean(lab[...,2]))
    return float(np.sqrt(a*a + b*b))

def append_jsonl(jsonl_path, metric_name, results, kimg=None, cur_nimg=None):
    rec = {"metric":metric_name,"results":results,"timestamp":time.time()}
    if kimg is not None: rec["kimg"]=float(kimg)
    if cur_nimg is not None: rec["cur_nimg"]=int(cur_nimg)
    p = Path(jsonl_path); p.parent.mkdir(parents=True,exist_ok=True)
    with open(p,"a",encoding="utf-8") as f:
        f.write(json.dumps(rec)+"\n")

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--before_dir", required=True)
    ap.add_argument("--after_dir",  required=True)
    ap.add_argument("--retouch_jsonl", default=None)
    ap.add_argument("--relight_jsonl", default=None)
    ap.add_argument("--kimg", type=float, default=None)
    ap.add_argument("--cur_nimg", type=int, default=None)
    ap.add_argument("--max_pairs", type=int, default=None)
    ap.add_argument("--max_size", type=int, default=1024)
    ap.add_argument("--target_luma", type=float, default=0.5)
    ap.add_argument("--low_clip", type=float, default=0.01)
    ap.add_argument("--high_clip", type=float, default=0.99)
    ap.add_argument("--device", default="cpu", choices=["cpu","cuda"])
    args = ap.parse_args()

    before = Path(args.before_dir); after = Path(args.after_dir)
    assert before.is_dir() and after.is_dir(), "before_dir/after_dir must exist"

    pairs = list_pairs(before, after, args.max_pairs)
    if not pairs:
        raise SystemExit("no matching filename pairs found")

    # Optional models
    device = "cuda" if (_HAS_LPIPS and args.device=="cuda" and torch.cuda.is_available()) else "cpu"

    lpips_model = None
    if _HAS_LPIPS:
        try:
            lpips_model = lpips.LPIPS(net='vgg').to(device)
            lpips_model.eval()
        except Exception as e:
            print("[warn] LPIPS init failed, skip lpips_face:", e)
            lpips_model=None
    else:
        print("[warn] 'lpips' not installed → skip lpips_face")

    face_app = None
    if _HAS_INSIGHT:
        try:
            face_app = FaceAnalysis(name='buffalo_l')
            face_app.prepare(ctx_id=0 if device=="cuda" else -1, det_size=(640,640))
        except Exception as e:
            print("[warn] insightface init failed, skip id_sim/bbox:", e)
            face_app=None
    else:
        print("[warn] 'insightface' not installed → skip id_sim")

    # Accumulators
    vals = {k:[] for k in [
        "id_sim","lpips_face","ssim_face",
        "skin_hf_energy","artifact_ratio",
        "face_luma_L1","clipped_ratio","wb_deltaE",
    ]}
    counts = {k:0 for k in vals.keys()}

    for (bp, ap_) in pairs:
        try:
            b = read_rgb(bp, args.max_size)
            a = read_rgb(ap_, args.max_size)
        except Exception as e:
            print(f"[skip] read error {bp.name}: {e}"); continue

        # face crops
        bb = get_face_bbox(face_app, b) if face_app else None
        ba = get_face_bbox(face_app, a) if face_app else None
        face_b = crop_by_bbox(b, bb) if bb else center_crop(b)
        face_a = crop_by_bbox(a, ba) if ba else center_crop(a)
        face_b, face_a = resize_pair(face_b, face_a, 256)

        # id_sim (ArcFace)
        if face_app:
            try:
                fb = face_app.get((face_b*255).astype(np.uint8))
                fa = face_app.get((face_a*255).astype(np.uint8))
                if fb and fa:
                    eb = fb[0].normed_embedding; ea = fa[0].normed_embedding
                    sim = float(np.dot(eb, ea))
                    if -1.0 <= sim <= 1.0 and math.isfinite(sim):
                        vals["id_sim"].append(sim); counts["id_sim"]+=1
            except Exception as e:
                print(f"[warn] id_sim failed {bp.name}: {e}")

        # LPIPS / SSIM on face
        if lpips_model:
            try:
                at = torch.from_numpy(face_b).permute(2,0,1).unsqueeze(0).float(); at = at*2-1
                bt = torch.from_numpy(face_a).permute(2,0,1).unsqueeze(0).float(); bt = bt*2-1
                at=at.to(device); bt=bt.to(device)
                with torch.no_grad():
                    d = lpips_model(at, bt).squeeze().detach().cpu().numpy().item()
                if math.isfinite(d):
                    vals["lpips_face"].append(float(d)); counts["lpips_face"]+=1
            except Exception as e:
                print(f"[warn] lpips failed {bp.name}: {e}")
        try:
            s = float(ssim(face_b, face_a, data_range=1.0, channel_axis=2))
            if math.isfinite(s):
                vals["ssim_face"].append(s); counts["ssim_face"]+=1
        except Exception as e:
            print(f"[warn] ssim failed {bp.name}: {e}")

        # Skin high-frequency (after)
        try:
            gA = cv2.cvtColor((face_a*255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32)/255.0
            hf = laplacian_energy(gA)
            if math.isfinite(hf):
                vals["skin_hf_energy"].append(hf); counts["skin_hf_energy"]+=1
        except Exception as e:
            print(f"[warn] hf failed {ap_.name}: {e}")

        # Artifact ratio: new strong edges increase
        try:
            gB = cv2.cvtColor((face_b*255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32)/255.0
            gA = cv2.cvtColor((face_a*255).astype(np.uint8), cv2.COLOR_RGB2GRAY).astype(np.float32)/255.0
            mb = sobel_mag(gB); ma = sobel_mag(gA)
            thr = float(np.percentile(mb, 95.0))
            strong_b = (mb > thr).astype(np.float32)
            strong_a = (ma > thr).astype(np.float32)
            art = float(np.maximum(strong_a-strong_b,0).mean())
            if math.isfinite(art):
                vals["artifact_ratio"].append(art); counts["artifact_ratio"]+=1
        except Exception as e:
            print(f"[warn] artifact failed {bp.name}: {e}")

        # Relight: luma target / clipping / wb deltaE
        try:
            Y = y_luma(face_a)
            l1 = float(np.mean(np.abs(Y - args.target_luma)))
            if math.isfinite(l1):
                vals["face_luma_L1"].append(l1); counts["face_luma_L1"]+=1
            clip = float(np.mean((Y <= args.low_clip)|(Y >= args.high_clip)))
            if math.isfinite(clip):
                vals["clipped_ratio"].append(clip); counts["clipped_ratio"]+=1
            de = deltaE_to_neutral(face_a)
            if math.isfinite(de):
                vals["wb_deltaE"].append(de); counts["wb_deltaE"]+=1
        except Exception as e:
            print(f"[warn] relight failed {ap_.name}: {e}")

    def m(x): return float(np.mean(x)) if len(x)>0 else None
    retouch = {
        "id_sim": m(vals["id_sim"]),
        "lpips_face": m(vals["lpips_face"]),
        "skin_hf_energy": m(vals["skin_hf_energy"]),
        "artifact_ratio": m(vals["artifact_ratio"]),
        "n_pairs": len(pairs),
        "n_id": counts["id_sim"], "n_lpips": counts["lpips_face"],
    }
    relight = {
        "face_luma_L1": m(vals["face_luma_L1"]),
        "clipped_ratio": m(vals["clipped_ratio"]),
        "wb_deltaE": m(vals["wb_deltaE"]),
        "lpips_face": m(vals["lpips_face"]) if counts["lpips_face"] else None,
        "ssim_face": m(vals["ssim_face"]),
        "n_pairs": len(pairs),
    }
    # drop None
    retouch = {k:v for k,v in retouch.items() if v is not None}
    relight = {k:v for k,v in relight.items() if v is not None}

    if args.retouch_jsonl:
        append_jsonl(args.retouch_jsonl, "retouch", retouch, kimg=args.kimg, cur_nimg=args.cur_nimg)
        print("[OK] retouch:", retouch)
    if args.relight_jsonl:
        append_jsonl(args.relight_jsonl, "relight", relight, kimg=args.kimg, cur_nimg=args.cur_nimg)
        print("[OK] relight:", relight)
    if not args.retouch_jsonl and not args.relight_jsonl:
        print("retouch:", retouch)
        print("relight:", relight)

if __name__ == "__main__":
    main()
