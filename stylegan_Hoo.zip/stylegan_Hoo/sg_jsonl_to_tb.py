
#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Convert StyleGAN-style JSONL logs (stats.jsonl, metric-*.jsonl) into TensorBoard event files.

Usage:
    python sg_jsonl_to_tb.py \
        --in "D:/runs/exp/stats.jsonl" \
        --in "D:/runs/exp/metric-*.jsonl" \
        --out "D:/runs/exp/tb_from_jsonl"

Then:
    tensorboard --logdir "D:/runs/exp/tb_from_jsonl" --port 6007 --bind_all
"""
import argparse, json, glob, math
from pathlib import Path

try:
    from torch.utils.tensorboard import SummaryWriter
    BACKEND = "torch"
except Exception:
    try:
        from tensorboardX import SummaryWriter
        BACKEND = "tensorboardX"
    except Exception as e:
        raise SystemExit("Install torch (torch.utils.tensorboard) or tensorboardX to write events.") from e


def to_float(x):
    try:
        v = float(x); 
        return v if math.isfinite(v) else None
    except Exception:
        return None


def iter_jsonl(path: Path):
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except Exception:
                continue
            yield rec


def flatten(d, prefix=""):
    if isinstance(d, dict):
        for k, v in d.items():
            p = f"{prefix}/{k}" if prefix else str(k)
            yield from flatten(v, p)
    else:
        yield prefix, d


def pick_step(rec):
    # Prefer kimg (-> images) then cur_nimg, else Progress/kimg.mean, then tick
    if "kimg" in rec:
        v = to_float(rec["kimg"])
        if v is not None:
            return int(round(v * 1000))
    if "cur_nimg" in rec:
        v = to_float(rec["cur_nimg"])
        if v is not None:
            return int(round(v))
    if "Progress/kimg" in rec and isinstance(rec["Progress/kimg"], dict):
        v = to_float(rec["Progress/kimg"].get("mean"))
        if v is not None:
            return int(round(v * 1000))
    if "tick" in rec:
        v = to_float(rec["tick"])
        if v is not None:
            return int(round(v))
    if "Progress/tick" in rec and isinstance(rec["Progress/tick"], dict):
        v = to_float(rec["Progress/tick"].get("mean"))
        if v is not None:
            return int(round(v))
    return None  # writer will increment implicit step


def is_metric_file(p: Path):
    return p.name.lower().startswith("metric-") or "metric" in p.name.lower()


def metric_prefix(p: Path, rec):
    name = p.stem.lower()
    if name.startswith("metric-"):
        return f"metrics/{name[7:]}"
    if "metric" in rec:
        return f"metrics/{str(rec['metric']).lower()}"
    return "metrics/unknown"


def write_events(files, out_dir: Path):
    writer = SummaryWriter(str(out_dir))
    implicit_step = 0
    for p in files:
        p = Path(p)
        if not p.exists():
            continue
        if is_metric_file(p):
            for rec in iter_jsonl(p):
                step = pick_step(rec)
                if step is None:
                    implicit_step += 1
                    step = implicit_step
                wall = to_float(rec.get("timestamp"))
                prefix = metric_prefix(p, rec)
                # If it has results dict, write that
                if isinstance(rec.get("results"), dict):
                    for k, v in rec["results"].items():
                        val = to_float(v)
                        if val is None: 
                            continue
                        writer.add_scalar(f"{prefix}/{k}".replace(" ", "_"), val, global_step=step, walltime=wall)
                else:
                    # Otherwise log numeric top-level keys (excluding step/time fields)
                    for k, v in rec.items():
                        if k in {"kimg","cur_nimg","tick","timestamp"}:
                            continue
                        val = to_float(v)
                        if val is None:
                            continue
                        writer.add_scalar(f"{prefix}/{k}".replace(" ", "_"), val, global_step=step, walltime=wall)
        else:
            # stats.jsonl style: nested dicts like {"Loss/G/loss":{"num":..,"mean":..,"std":..}, ...}
            for rec in iter_jsonl(p):
                step = pick_step(rec)
                if step is None:
                    implicit_step += 1
                    step = implicit_step
                wall = to_float(rec.get("timestamp"))
                for k, v in rec.items():
                    if isinstance(v, dict):
                        # write mean/std/num separately
                        for stat_key, stat_val in v.items():
                            val = to_float(stat_val)
                            if val is None:
                                continue
                            tag = f"stats/{k}/{stat_key}".replace(" ", "_")
                            writer.add_scalar(tag, val, global_step=step, walltime=wall)
                    else:
                        # numeric top-level fallbacks
                        val = to_float(v)
                        if val is None:
                            continue
                        tag = f"stats/{k}".replace(" ", "_")
                        writer.add_scalar(tag, val, global_step=step, walltime=wall)
    writer.flush()
    writer.close()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--in", dest="inputs", action="append", required=True, help="Input JSONL path(s) or globs; repeat --in to add more")
    ap.add_argument("--out", required=True, help="Output directory for TensorBoard event files")
    args = ap.parse_args()

    files = []
    for pat in args.inputs:
        files.extend(glob.glob(pat))
    if not files:
        raise SystemExit("No input files found.")
    out_dir = Path(args.out)
    out_dir.mkdir(parents=True, exist_ok=True)
    write_events(files, out_dir)
    print(f"[OK] Wrote TensorBoard events to: {out_dir} (backend={BACKEND})")


if __name__ == "__main__":
    main()
