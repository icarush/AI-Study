import cv2
import numpy as np
# import  time
import torch
from torch.nn import functional as F
import torch.nn as nn


def encode_segmentation_rgb(segmentation, no_neck=True):
    parse = segmentation

    face_part_ids = [1, 2, 3, 4, 5, 6, 10, 12, 13] if no_neck else [1, 2, 3, 4, 5, 6, 7, 8, 10, 12, 13, 14]
    mouth_id = 11
    # hair_id = 17
    face_map = np.zeros([parse.shape[0], parse.shape[1]])
    mouth_map = np.zeros([parse.shape[0], parse.shape[1]])
    # hair_map = np.zeros([parse.shape[0], parse.shape[1]])

    for valid_id in face_part_ids:
        valid_index = np.where(parse == valid_id)
        face_map[valid_index] = 255
    valid_index = np.where(parse == mouth_id)
    mouth_map[valid_index] = 255
    # valid_index = np.where(parse==hair_id)
    # hair_map[valid_index] = 255
    # return np.stack([face_map, mouth_map,hair_map], axis=2)
    return np.stack([face_map, mouth_map], axis=2)


class SoftErosion(nn.Module):
    def __init__(self, kernel_size=15, threshold=0.6, iterations=1):
        super(SoftErosion, self).__init__()
        r = kernel_size // 2
        self.padding = r
        self.iterations = iterations
        self.threshold = threshold

        # Create kernel
        # note: torch.meshgrid warning about indexing argument is fine here
        y_indices, x_indices = torch.meshgrid(torch.arange(0., kernel_size), torch.arange(0., kernel_size))
        dist = torch.sqrt((x_indices - r) ** 2 + (y_indices - r) ** 2)
        kernel = dist.max() - dist
        kernel /= kernel.sum()
        kernel = kernel.view(1, 1, *kernel.shape)
        self.register_buffer('weight', kernel)

    def forward(self, x):
        x = x.float()
        for i in range(self.iterations - 1):
            x = torch.min(x, F.conv2d(x, weight=self.weight, groups=x.shape[1], padding=self.padding))
        x = F.conv2d(x, weight=self.weight, groups=x.shape[1], padding=self.padding)

        mask = x >= self.threshold
        x[mask] = 1.0
        x[~mask] /= x[~mask].max()

        return x, mask


def postprocess(swapped_face, target, target_mask, smooth_mask):
    # target_mask = cv2.resize(target_mask, (self.size,  self.size))

    mask_tensor = torch.from_numpy(target_mask.copy().transpose((2, 0, 1))).float().mul_(1 / 255.0).cuda()
    face_mask_tensor = mask_tensor[0] + mask_tensor[1]

    soft_face_mask_tensor, _ = smooth_mask(face_mask_tensor.unsqueeze_(0).unsqueeze_(0))
    soft_face_mask_tensor.squeeze_()

    soft_face_mask = soft_face_mask_tensor.cpu().numpy()
    soft_face_mask = soft_face_mask[:, :, np.newaxis]

    result = swapped_face * soft_face_mask + target * (1 - soft_face_mask)
    result = result[:, :, ::-1]  # .astype(np.uint8)
    return result


def reverse2wholeimage(b_align_crop_tenor_list, swaped_imgs, mats, crop_size, oriimg, logoclass, save_path='',
                       no_simswaplogo=False, pasring_model=None, norm=None, use_mask=False):

    target_image_list = []
    img_mask_list = []
    if use_mask:
        smooth_mask = SoftErosion(kernel_size=17, threshold=0.9, iterations=7).cuda()
    else:
        smooth_mask = None

    # iterate through results
    for idx, (swaped_img, mat, source_img) in enumerate(zip(swaped_imgs, mats, b_align_crop_tenor_list)):
        # swaped_img: tensor CHW -> HWC numpy
        try:
            swaped_img = swaped_img.cpu().detach().numpy().transpose((1, 2, 0))
        except Exception as e:
            print(f"[WARN] failed converting swapped_img to numpy for idx={idx}: {e}")
            continue

        img_white = np.full((crop_size, crop_size), 255, dtype=np.uint8)

        # Coerce mat into a (2,3) float32 matrix
        try:
            mat_arr = np.asarray(mat, dtype=np.float32)
        except Exception as e:
            print(f"[WARN] cannot convert mat to ndarray for idx={idx}: {e} -- skipping")
            continue

        # normalize shapes: accept flat length-6, or (2,3)
        if mat_arr.ndim == 1 and mat_arr.size == 6:
            try:
                mat_arr = mat_arr.reshape((2, 3))
            except Exception as e:
                print(f"[WARN] reshape mat failed idx={idx}: {e} -- skipping")
                continue
        elif mat_arr.shape == (2, 3):
            pass
        else:
            # unexpected shape (e.g., (3,) or (6,1) etc.) -> skip face with warning
            print(f"[WARN] invalid affine matrix for idx={idx}, skipping face: unexpected affine mat shape {mat_arr.shape}; mat repr: {mat_arr}")
            continue

        # Precompute inverse using OpenCV (for fallback only)
        try:
            mat_rev = cv2.invertAffineTransform(mat_arr)
        except Exception:
            mat_rev = None

        orisize = (oriimg.shape[1], oriimg.shape[0])

        # --- mask/parsing branch ---
        if use_mask and pasring_model is not None:
            try:
                source_img_norm = norm(source_img)
                source_img_512 = F.interpolate(source_img_norm, size=(512, 512))
                out = pasring_model(source_img_512)[0]
                parsing = out.squeeze(0).detach().cpu().numpy().argmax(0)
                vis_parsing_anno = parsing.copy().astype(np.uint8)
                tgt_mask = encode_segmentation_rgb(vis_parsing_anno)
            except Exception as e:
                print(f"[WARN] parsing model failed at idx={idx}: {e}")
                tgt_mask = None

            if tgt_mask is not None and tgt_mask.sum() >= 5000:
                target_mask = cv2.resize(tgt_mask, (crop_size, crop_size))
                try:
                    target_image_parsing = postprocess(swaped_img,
                                                      source_img[0].cpu().detach().numpy().transpose((1, 2, 0)),
                                                      target_mask, smooth_mask)
                except Exception as e:
                    print(f"[WARN] postprocess failed idx={idx}: {e}")
                    # fallback to using swapped_img
                    target_image_parsing = swaped_img[..., ::-1]  # BGR fallback

                # ensure uint8 before warp
                if np.issubdtype(target_image_parsing.dtype, np.floating):
                    try:
                        if np.nanmax(target_image_parsing) <= 1.1:
                            prewarp = (target_image_parsing * 255.0).clip(0, 255).astype(np.uint8)
                        else:
                            prewarp = np.nan_to_num(target_image_parsing).clip(0, 255).astype(np.uint8)
                    except Exception:
                        prewarp = np.nan_to_num(target_image_parsing).clip(0, 255).astype(np.uint8)
                else:
                    prewarp = target_image_parsing.clip(0, 255).astype(np.uint8)

                # prefer OpenCV inverse-map (let OpenCV invert internally)
                try:
                    target_image = cv2.warpAffine(prewarp, mat_arr, orisize,
                                                  flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                                                  borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0))
                except Exception as e1:
                    # fallback to mat_rev if available
                    try:
                        if mat_rev is not None:
                            target_image = cv2.warpAffine(prewarp, mat_rev, orisize,
                                                          flags=cv2.INTER_LINEAR,
                                                          borderMode=cv2.BORDER_REPLICATE)
                        else:
                            raise e1
                    except Exception as e2:
                        print(f"[WARN] warp failed for parsed face idx={idx}: {e2}")
                        target_image = np.zeros((orisize[1], orisize[0], 3), dtype=np.uint8)
            else:
                # parsing small or failed -> fallback warp swapped image
                tmp = swaped_img.copy()
                if tmp.dtype != np.uint8:
                    try:
                        if tmp.max() <= 1.1:
                            tmp = (tmp * 255).astype(np.uint8)
                        else:
                            tmp = tmp.astype(np.uint8)
                    except Exception:
                        tmp = np.nan_to_num(tmp).clip(0, 255).astype(np.uint8)
                else:
                    tmp = tmp.copy()

                try:
                    target_image = cv2.warpAffine(tmp, mat_arr, orisize,
                                                  flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                                                  borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0))
                except Exception:
                    try:
                        if mat_rev is not None:
                            target_image = cv2.warpAffine(tmp, mat_rev, orisize, flags=cv2.INTER_LINEAR,
                                                          borderMode=cv2.BORDER_REPLICATE)
                        else:
                            raise
                    except Exception as e:
                        print(f"[WARN] fallback warp failed idx={idx}: {e}")
                        target_image = np.zeros((orisize[1], orisize[0], 3), dtype=np.uint8)
        else:
            # no mask: warp swapped image directly
            tmp = swaped_img.copy()
            if tmp.dtype != np.uint8:
                try:
                    if tmp.max() <= 1.1:
                        tmp = (tmp * 255).astype(np.uint8)
                    else:
                        tmp = tmp.astype(np.uint8)
                except Exception:
                    tmp = np.nan_to_num(tmp).clip(0, 255).astype(np.uint8)
            else:
                tmp = tmp.copy()

            try:
                target_image = cv2.warpAffine(tmp, mat_arr, orisize,
                                              flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                                              borderMode=cv2.BORDER_CONSTANT, borderValue=(0, 0, 0))
            except Exception:
                try:
                    if mat_rev is not None:
                        target_image = cv2.warpAffine(tmp, mat_rev, orisize, flags=cv2.INTER_LINEAR,
                                                      borderMode=cv2.BORDER_REPLICATE)
                    else:
                        raise
                except Exception as e:
                    print(f"[WARN] warp no-mask failed idx={idx}: {e}")
                    target_image = np.zeros((orisize[1], orisize[0], 3), dtype=np.uint8)

        # warp white patch to produce mask (single channel)
        try:
            iw = img_white.copy()
            if iw.dtype != np.uint8:
                iw = iw.astype(np.uint8)
            try:
                img_white_warped = cv2.warpAffine(iw, mat_arr, orisize,
                                                  flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                                                  borderMode=cv2.BORDER_CONSTANT, borderValue=0)
            except Exception:
                if mat_rev is not None:
                    img_white_warped = cv2.warpAffine(iw, mat_rev, orisize, flags=cv2.INTER_LINEAR,
                                                      borderMode=cv2.BORDER_REPLICATE)
                else:
                    raise
        except Exception as e:
            print(f"[WARN] img_white warp failed idx={idx}: {e}")
            img_white_warped = np.zeros((orisize[1], orisize[0]), dtype=np.uint8)

        # mask postprocess
        try:
            img_white_warped = img_white_warped.astype(float)
            img_white_warped[img_white_warped > 20] = 255
            img_mask = img_white_warped
            kernel = np.ones((40, 40), np.uint8)
            img_mask = cv2.erode(img_mask, kernel, iterations=1)
            kernel_size = (20, 20)
            blur_size = tuple(2 * i + 1 for i in kernel_size)
            img_mask = cv2.GaussianBlur(img_mask, blur_size, 0)
        except Exception as e:
            print(f"[WARN] Mask postprocess failed idx={idx}: {e}")
            img_mask = np.zeros((orisize[1], orisize[0]), dtype=float)

        img_mask /= 255.0
        img_mask = np.reshape(img_mask, [img_mask.shape[0], img_mask.shape[1], 1])

        # ensure target_image numeric float for blending
        try:
            target_image = np.array(target_image, dtype=float)
        except Exception:
            target_image = np.zeros((orisize[1], orisize[0], 3), dtype=float)

        img_mask_list.append(img_mask)
        target_image_list.append(target_image)

    # blend
    img = np.array(oriimg, dtype=float)
    for img_mask, target_image in zip(img_mask_list, target_image_list):
        try:
            img = img_mask * target_image + (1 - img_mask) * img
        except Exception as e:
            print(f"[WARN] blending failed for one target: {e}")

    final_img = img.astype(np.uint8)
    if not no_simswaplogo:
        final_img = logoclass.apply_frames(final_img)
    cv2.imwrite(save_path, final_img)
