'''
Author: Naiyuan liu
Github: https://github.com/NNNNAI
Date: 2021-11-23 17:03:58
LastEditors: Naiyuan liu
LastEditTime: 2021-11-24 16:46:04
Description: 
'''
from __future__ import division
import collections
import numpy as np
import glob
import os
import os.path as osp
import cv2
from insightface.model_zoo import model_zoo
from insightface_func.utils import face_align_ffhqandnewarc as face_align

__all__ = ['Face_detect_crop', 'Face']

Face = collections.namedtuple('Face', [
    'bbox', 'kps', 'det_score', 'embedding', 'gender', 'age',
    'embedding_norm', 'normed_embedding',
    'landmark'
])

Face.__new__.__defaults__ = (None, ) * len(Face._fields)


class Face_detect_crop:
    def __init__(self, name, root='~/.insightface_func/models'):
        self.models = {}
        root = os.path.expanduser(root)
        onnx_files = glob.glob(osp.join(root, name, '*.onnx'))
        onnx_files = sorted(onnx_files)
        for onnx_file in onnx_files:
            if onnx_file.find('_selfgen_')>0:
                #print('ignore:', onnx_file)
                continue
            model = model_zoo.get_model(onnx_file)
            if model.taskname not in self.models:
                print('find model:', onnx_file, model.taskname)
                self.models[model.taskname] = model
            else:
                print('duplicated model task type, ignore:', onnx_file, model.taskname)
                del model
        assert 'detection' in self.models
        self.det_model = self.models['detection']


    def prepare(self, ctx_id, det_thresh=0.5, det_size=(640, 640), mode ='None'):
        self.det_thresh = det_thresh
        self.mode = mode
        assert det_size is not None
        print('set det-size:', det_size)
        self.det_size = det_size
        for taskname, model in self.models.items():
            if taskname=='detection':
                model.prepare(ctx_id, input_size=det_size)
            else:
                model.prepare(ctx_id)

    def get(self, img, crop_size, max_num=0):
        bboxes, kpss = self._safe_detect(img, det_size=self.det_size, det_thresh=self.det_thresh)
        if bboxes.shape[0] == 0:
            return None
        # ret = []
        # for i in range(bboxes.shape[0]):
        #     bbox = bboxes[i, 0:4]
        #     det_score = bboxes[i, 4]
        #     kps = None
        #     if kpss is not None:
        #         kps = kpss[i]
        #     M, _ = face_align.estimate_norm(kps, crop_size, mode ='None') 
        #     align_img = cv2.warpAffine(img, M, (crop_size, crop_size), borderValue=0.0)
        # for i in range(bboxes.shape[0]):
        #     kps = None
        #     if kpss is not None:
        #         kps = kpss[i]
        #     M, _ = face_align.estimate_norm(kps, crop_size, mode ='None') 
        #     align_img = cv2.warpAffine(img, M, (crop_size, crop_size), borderValue=0.0)

        det_score = bboxes[..., 4]

        # select the face with the hightest detection score
        best_index = np.argmax(det_score)

        kps = None
        if kpss is not None:
            kps = kpss[best_index]
        M, _ = face_align.estimate_norm(kps, crop_size, mode = self.mode) 
        align_img = cv2.warpAffine(img, M, (crop_size, crop_size), borderValue=0.0)
        
        return [align_img], [M]

    # ---------- BEGIN PATCH: robust detect wrapper ----------
    def _safe_detect(self, img, det_size=None, det_thresh=None):
        """
        Robust wrapper that tries multiple possible detect() signatures
        and returns the first successful (bboxes, kps) result.
        """
        if det_size is None:
            det_size = getattr(self, "det_size", None)
        if det_thresh is None:
            det_thresh = getattr(self, "det_thresh", None)

        # candidate kwargs to try (order matters: most likely first)
        candidate_kwargs = [
            {"threshold": det_thresh, "input_size": det_size},
            {"det_thresh": det_thresh, "input_size": det_size},
            {"score_thresh": det_thresh, "input_size": det_size},
            {"conf": det_thresh, "input_size": det_size},
            {"input_size": det_size},   # sometimes only input_size is used
            {},                         # bare call
        ]

        last_exc = None
        for kwargs in candidate_kwargs:
            # remove None values to avoid unexpected kwargs
            kwargs = {k: v for k, v in kwargs.items() if v is not None}
            try:
                res = self.det_model.detect(img, **kwargs)
                # some detect implementations return (bboxes, kps), others return (bboxes, kpss, scores) etc.
                if isinstance(res, tuple) and len(res) >= 2:
                    # typical case: (bboxes, kpss)
                    return res[0], res[1]
                else:
                    # if detect returns a different shape, just return it and let caller handle / error
                    return res
            except TypeError as e:
                # wrong args signature — try next signature
                last_exc = e
                continue
            except Exception as e:
                # other errors: print warning and try next
                last_exc = e
                # print small warning to help debugging
                try:
                    print(f"[WARN] det_model.detect raised {type(e).__name__}: {e}; tried kwargs={kwargs}")
                except Exception:
                    pass
                continue

        # If we get here, all attempts failed
        raise RuntimeError(f"_safe_detect: all detect() attempts failed. Last error: {last_exc}")
    # ---------- END PATCH ----------

