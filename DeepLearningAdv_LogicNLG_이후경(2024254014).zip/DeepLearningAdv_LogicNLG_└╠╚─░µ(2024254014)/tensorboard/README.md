This folder is for storing the training logs
